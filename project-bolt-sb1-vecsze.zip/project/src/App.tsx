import React from 'react';
import MovieRow from './components/MovieRow';
import { movies } from './data/movies';

function App() {
  return (
    <div className="relative min-h-screen bg-gradient-to-b from-gray-900/10 to-[#010511] lg:h-[140vh]">
      <main className="relative pb-24 lg:space-y-24">
        <section className="md:space-y-16">
          <MovieRow title="Trending Now" movies={movies.trending} />
          <MovieRow title="Popular" movies={movies.popular} />
          <MovieRow title="New Releases" movies={movies.newReleases} />
          <MovieRow title="Watch Again" movies={movies.watchAgain} />
        </section>
      </main>
    </div>
  );
}

export default App;