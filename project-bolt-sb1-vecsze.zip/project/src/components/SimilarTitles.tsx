import React from 'react';
import { movies } from '../data/movies';
import MovieCard from './MovieCard';

interface SimilarTitlesProps {
  movieIds: number[];
}

const SimilarTitles: React.FC<SimilarTitlesProps> = ({ movieIds }) => {
  const allMovies = [
    ...movies.trending,
    ...movies.popular,
    ...movies.newReleases,
    ...movies.watchAgain,
  ];

  const similarMovies = movieIds
    .map((id) => allMovies.find((movie) => movie.id === id))
    .filter((movie): movie is typeof allMovies[0] => movie !== undefined);

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
      {similarMovies.map((movie) => (
        <MovieCard key={movie.id} movie={movie} />
      ))}
    </div>
  );
};

export default SimilarTitles;