import React, { useRef } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import MovieCard from './MovieCard';

interface Movie {
  id: number;
  title: string;
  image: string;
  duration: string;
  type: 'movie' | 'series';
  rating: number;
  year?: string;
  ageRating?: string;
  genres?: string[];
  cast?: string[];
  director?: string;
  description: string;
  similarTitles?: number[];
}

interface MovieRowProps {
  title: string;
  movies: Movie[];
}

const MovieRow: React.FC<MovieRowProps> = ({ title, movies }) => {
  const rowRef = useRef<HTMLDivElement>(null);

  const handleScroll = (direction: 'left' | 'right') => {
    if (rowRef.current) {
      const { scrollLeft, clientWidth } = rowRef.current;
      const scrollTo =
        direction === 'left'
          ? scrollLeft - clientWidth
          : scrollLeft + clientWidth;
      
      rowRef.current.scrollTo({
        left: scrollTo,
        behavior: 'smooth',
      });
    }
  };

  if (!movies || movies.length === 0) {
    return null;
  }

  return (
    <div className="space-y-2 md:space-y-4">
      <h2 className="text-xl font-semibold md:text-2xl pl-4">{title}</h2>
      
      <div className="group relative">
        <ChevronLeft
          className="absolute top-0 bottom-0 left-2 z-40 m-auto h-9 w-9 
          cursor-pointer opacity-0 transition hover:scale-125 group-hover:opacity-100"
          onClick={() => handleScroll('left')}
        />
        
        <div
          ref={rowRef}
          className="flex items-center space-x-2 overflow-x-scroll scrollbar-hide md:space-x-4 md:p-4"
        >
          {movies.map((movie) => (
            <MovieCard key={movie.id} movie={movie} />
          ))}
        </div>
        
        <ChevronRight
          className="absolute top-0 bottom-0 right-2 z-40 m-auto h-9 w-9 
          cursor-pointer opacity-0 transition hover:scale-125 group-hover:opacity-100"
          onClick={() => handleScroll('right')}
        />
      </div>
    </div>
  );
};

export default MovieRow;