import React from 'react';
import { Star } from 'lucide-react';

interface Movie {
  id: number;
  title: string;
  image: string;
  duration: string;
  type: 'movie' | 'series';
  rating: number;
  year?: string;
  ageRating?: string;
  genres?: string[];
  cast?: string[];
  director?: string;
  description: string;
  similarTitles?: number[];
}

interface MovieCardProps {
  movie: Movie;
}

const MovieCard: React.FC<MovieCardProps> = ({ movie }) => {
  return (
    <div className="relative h-48 min-w-[180px] cursor-pointer transition duration-200 ease-out md:h-64 md:min-w-[260px] hover:scale-105">
      <img
        src={movie.image}
        alt={movie.title}
        className="rounded-sm object-cover md:rounded w-full h-full"
      />
      
      <div className="absolute bottom-0 left-0 right-0 p-3 bg-gradient-to-t from-black/80 to-transparent">
        <h3 className="text-white font-semibold truncate">{movie.title}</h3>
        
        <div className="flex items-center space-x-2 text-sm text-gray-300">
          <span>{movie.type === 'movie' ? '🎬' : '📺'}</span>
          <span>{movie.duration}</span>
          <div className="flex items-center">
            <Star className="h-4 w-4 text-yellow-500 fill-yellow-500" />
            <span className="ml-1">{movie.rating}/5</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MovieCard;