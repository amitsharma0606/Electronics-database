import React, { useState, useEffect } from 'react';
import { Play, Info } from 'lucide-react';

interface HeroMovie {
  title: string;
  description: string;
  image: string;
}

const featuredMovies: HeroMovie[] = [
  {
    title: "Inception",
    description: "A thief who enters the dreams of others to steal their secrets gets a chance at redemption when he is offered a task that could change everything.",
    image: "https://images.unsplash.com/photo-1626814026160-2237a95fc5a0?auto=format&fit=crop&w=2070&q=80"
  },
  {
    title: "Interstellar",
    description: "A team of explorers travel through a wormhole in space in an attempt to ensure humanity's survival.",
    image: "https://images.unsplash.com/photo-1506477331477-33d5d8b3dc85?auto=format&fit=crop&w=2070&q=80"
  },
  {
    title: "The Matrix",
    description: "A computer programmer discovers that reality as he knows it is a simulation created by machines, and joins a rebellion to break free.",
    image: "https://images.unsplash.com/photo-1485846234645-a62644f84728?auto=format&fit=crop&w=2070&q=80"
  }
];

const Hero: React.FC = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isTransitioning, setIsTransitioning] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => {
      setIsTransitioning(true);
      setTimeout(() => {
        setCurrentIndex((prev) => (prev + 1) % featuredMovies.length);
        setIsTransitioning(false);
      }, 500);
    }, 8000);

    return () => clearInterval(interval);
  }, []);

  const currentMovie = featuredMovies[currentIndex];

  return (
    <div className="relative h-[90vh] w-full overflow-hidden">
      {/* Background Image */}
      <div 
        className={`absolute inset-0 transition-opacity duration-500 ${
          isTransitioning ? 'opacity-0' : 'opacity-100'
        }`}
      >
        <img
          src={currentMovie.image}
          className="w-full h-full object-cover"
          alt={currentMovie.title}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#141414] via-transparent to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#141414] via-[#141414]/20 to-transparent" />
      </div>

      {/* Content */}
      <div 
        className={`absolute bottom-[30%] left-[4%] max-w-xl transition-all duration-500 ${
          isTransitioning ? 'opacity-0 translate-y-8' : 'opacity-100 translate-y-0'
        }`}
      >
        <h1 className="text-7xl font-bold mb-4">{currentMovie.title}</h1>
        <p className="text-lg mb-6">{currentMovie.description}</p>
        <div className="flex gap-4">
          <button className="flex items-center gap-2 bg-white text-black px-8 py-3 rounded hover:bg-white/90 transition">
            <Play className="w-6 h-6" /> Play
          </button>
          <button className="flex items-center gap-2 bg-gray-500/70 text-white px-8 py-3 rounded hover:bg-gray-500/50 transition">
            <Info className="w-6 h-6" /> More Info
          </button>
        </div>
      </div>

      {/* Indicators */}
      <div className="absolute bottom-[15%] left-[4%] flex gap-2">
        {featuredMovies.map((_, index) => (
          <button
            key={index}
            className={`w-2 h-2 rounded-full transition-all duration-300 ${
              index === currentIndex ? 'bg-white w-4' : 'bg-white/50'
            }`}
            onClick={() => setCurrentIndex(index)}
          />
        ))}
      </div>
    </div>
  );
};

export default Hero;