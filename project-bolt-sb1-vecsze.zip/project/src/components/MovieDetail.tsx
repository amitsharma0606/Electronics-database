import React from 'react';
import { Play, Plus, ThumbsUp, Star, Clock, Film, Tv, X, Share2 } from 'lucide-react';
import SimilarTitles from './SimilarTitles';

interface MovieDetailProps {
  movie: {
    id: number;
    title: string;
    image: string;
    duration: string;
    type: 'movie' | 'series';
    rating: number;
    year?: string;
    ageRating?: string;
    genres?: string[];
    cast?: string[];
    director?: string;
    description: string;
    similarTitles?: number[];
  };
  onClose: () => void;
}

const MovieDetail: React.FC<MovieDetailProps> = ({ movie, onClose }) => {
  return (
    <div className="fixed inset-0 bg-black/90 z-50 overflow-y-auto">
      <div className="relative min-h-screen">
        {/* Hero Section */}
        <div className="relative h-[70vh]">
          <img
            src={movie.image}
            alt={movie.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent" />
          
          {/* Close Button */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 bg-black/60 rounded-full hover:bg-black/80"
          >
            <X className="w-6 h-6" />
          </button>

          {/* Content Overlay */}
          <div className="absolute bottom-0 left-0 right-0 p-8">
            <h1 className="text-5xl font-bold mb-4">{movie.title}</h1>
            
            <div className="flex items-center gap-6 mb-6">
              <div className="flex items-center gap-2">
                <Star className="w-5 h-5 text-yellow-400 fill-yellow-400" />
                <span className="text-lg">{movie.rating}/5</span>
              </div>
              <span className="text-lg">{movie.year}</span>
              <span className="px-2 py-1 border border-white/40 text-sm">
                {movie.ageRating}
              </span>
              <div className="flex items-center gap-2">
                {movie.type === 'movie' ? (
                  <Film className="w-5 h-5" />
                ) : (
                  <Tv className="w-5 h-5" />
                )}
                <span>{movie.duration}</span>
              </div>
            </div>

            <div className="flex gap-3">
              <button className="flex items-center gap-2 bg-white text-black px-8 py-3 rounded hover:bg-white/90 transition">
                <Play className="w-6 h-6" /> Play
              </button>
              <button className="p-3 bg-gray-500/70 rounded-full hover:bg-gray-500/50 transition">
                <Plus className="w-6 h-6" />
              </button>
              <button className="p-3 bg-gray-500/70 rounded-full hover:bg-gray-500/50 transition">
                <ThumbsUp className="w-6 h-6" />
              </button>
              <button className="p-3 bg-gray-500/70 rounded-full hover:bg-gray-500/50 transition">
                <Share2 className="w-6 h-6" />
              </button>
            </div>
          </div>
        </div>

        {/* Details Section */}
        <div className="px-8 py-6 grid grid-cols-3 gap-8">
          <div className="col-span-2 space-y-6">
            <p className="text-lg leading-relaxed">{movie.description}</p>
            
            <div>
              <h3 className="text-gray-400 mb-2">Cast</h3>
              <p className="text-lg">{movie.cast?.join(', ')}</p>
            </div>
            
            <div>
              <h3 className="text-gray-400 mb-2">Director</h3>
              <p className="text-lg">{movie.director}</p>
            </div>
            
            <div>
              <h3 className="text-gray-400 mb-2">Genres</h3>
              <div className="flex flex-wrap gap-2">
                {movie.genres?.map((genre) => (
                  <span
                    key={genre}
                    className="px-3 py-1 bg-gray-800 rounded-full text-sm"
                  >
                    {genre}
                  </span>
                ))}
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <h3 className="text-gray-400 mb-2">Maturity rating</h3>
              <div className="flex items-center gap-2">
                <span className="px-2 py-1 border border-white/40">
                  {movie.ageRating}
                </span>
                <span className="text-sm">Recommended for ages {movie.ageRating} and up</span>
              </div>
            </div>
          </div>
        </div>

        {/* Similar Titles */}
        <div className="px-8 py-6">
          <h2 className="text-2xl font-semibold mb-4">More Like This</h2>
          <SimilarTitles movieIds={movie.similarTitles || []} />
        </div>
      </div>
    </div>
  );
};

export default MovieDetail;