import React from 'react';
import { Search, Bell, ChevronDown } from 'lucide-react';

interface NavbarProps {
  isScrolled: boolean;
}

const Navbar: React.FC<NavbarProps> = ({ isScrolled }) => {
  return (
    <nav className={`fixed top-0 w-full z-50 transition-all duration-500 ${isScrolled ? 'bg-[#141414]' : 'bg-transparent'}`}>
      <div className="px-4 py-4 flex items-center justify-between">
        <div className="flex items-center gap-8">
          <h1 className="text-red-600 text-3xl font-bold">NETFLIX</h1>
          <div className="hidden md:flex items-center gap-6">
            <a href="#" className="text-sm text-white/90 hover:text-white">Home</a>
            <a href="#" className="text-sm text-white/90 hover:text-white">TV Shows</a>
            <a href="#" className="text-sm text-white/90 hover:text-white">Movies</a>
            <a href="#" className="text-sm text-white/90 hover:text-white">New & Popular</a>
            <a href="#" className="text-sm text-white/90 hover:text-white">My List</a>
          </div>
        </div>

        <div className="flex items-center gap-6">
          <Search className="w-5 h-5 text-white/90 hover:text-white cursor-pointer" />
          <Bell className="w-5 h-5 text-white/90 hover:text-white cursor-pointer" />
          <div className="flex items-center gap-2 cursor-pointer group">
            <img
              src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=100&q=80"
              alt="Profile"
              className="w-8 h-8 rounded"
            />
            <ChevronDown className="w-4 h-4 text-white/90 group-hover:text-white transition-transform group-hover:rotate-180" />
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;