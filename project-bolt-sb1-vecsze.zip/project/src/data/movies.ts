export const movies = {
  trending: [
    {
      id: 1,
      title: "Inception",
      image: "https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=500&q=80",
      duration: "2h 28m",
      type: "movie",
      rating: 5,
      year: "2010",
      ageRating: "PG-13",
      genres: ["Action", "Sci-Fi", "Thriller"],
      cast: ["Leonardo DiCaprio", "Joseph Gordon-Levitt", "Ellen Page"],
      director: "Christopher Nolan",
      description: "A thief who enters the dreams of others to steal their secrets gets a chance at redemption when he is offered a task that could change everything.",
      similarTitles: [2, 3, 4]
    },
    {
      id: 2,
      title: "The Matrix",
      image: "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=500&q=80",
      duration: "2h 16m",
      type: "movie",
      rating: 5,
      year: "1999",
      ageRating: "R",
      genres: ["Action", "Sci-Fi"],
      cast: ["Keanu Reeves", "Laurence Fishburne", "Carrie-Anne Moss"],
      director: "The Wachowskis",
      description: "A computer programmer discovers that reality as he knows it is a simulation created by machines, and joins a rebellion to break free.",
      similarTitles: [1, 3, 4]
    }
  ],
  popular: [
    {
      id: 3,
      title: "Stranger Things",
      image: "https://images.unsplash.com/photo-1572883454114-1cf0031ede2a?auto=format&fit=crop&w=500&q=80",
      duration: "4 Seasons",
      type: "series",
      rating: 4,
      year: "2016",
      ageRating: "TV-14",
      genres: ["Drama", "Fantasy", "Horror"],
      cast: ["Millie Bobby Brown", "Finn Wolfhard", "Winona Ryder"],
      director: "The Duffer Brothers",
      description: "When a young boy vanishes, a small town uncovers a mystery involving secret experiments, terrifying supernatural forces, and one strange little girl.",
      similarTitles: [4, 5, 6]
    }
  ],
  newReleases: [
    {
      id: 4,
      title: "Dune",
      image: "https://images.unsplash.com/photo-1547496502-affa22d38842?auto=format&fit=crop&w=500&q=80",
      duration: "2h 35m",
      type: "movie",
      rating: 4,
      year: "2021",
      ageRating: "PG-13",
      genres: ["Action", "Adventure", "Drama"],
      cast: ["Timothée Chalamet", "Rebecca Ferguson", "Zendaya"],
      director: "Denis Villeneuve",
      description: "A noble family becomes embroiled in a war for control over the galaxy's most valuable asset while its heir becomes troubled by visions of a dark future.",
      similarTitles: [1, 2, 3]
    }
  ],
  watchAgain: [
    {
      id: 5,
      title: "Breaking Bad",
      image: "https://images.unsplash.com/photo-1562159278-1253a58da141?auto=format&fit=crop&w=500&q=80",
      duration: "5 Seasons",
      type: "series",
      rating: 5,
      year: "2008",
      ageRating: "TV-MA",
      genres: ["Crime", "Drama", "Thriller"],
      cast: ["Bryan Cranston", "Aaron Paul"],
      director: "Vince Gilligan",
      description: "A high school chemistry teacher turned methamphetamine manufacturer partners with a former student to secure his family's financial future as he battles terminal lung cancer.",
      similarTitles: [3, 4, 6]
    }
  ]
};